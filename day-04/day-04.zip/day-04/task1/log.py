with open("log.txt","w") as f:
    f.write("first\n")
    
with open("log.txt","a") as f:
   
with open("log.txt") as f:
    print(f.read())

    
