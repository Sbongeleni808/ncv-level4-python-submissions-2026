name = " Thandi  mokoena "
print(len(name))
print(len(name.strip()))
print(name.strip().upper())