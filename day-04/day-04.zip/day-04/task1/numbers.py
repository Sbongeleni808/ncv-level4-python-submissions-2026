with open("scores","w") as f :
    for mark in [65 ,72 ,48]:
        f.write(str(mark)+"\n")
total=0
with open("scores.txt","r") as f:
    for line in f:
        total= total+int(line)
        
print(total)