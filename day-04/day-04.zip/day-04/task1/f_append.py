# NCV Level 4 | Day 4 Files Strings Batch | example: f_append
# Type it in Thonny, run it, then change one thing.
with open("log.txt","w") as f:
   f.write("first\n")
   f.write("second\n")
   f.write("third\n")

with open("log.txt", "a") as f:
    f.write("second\n")
with open("log.txt") as f:
    lines = f.readlines()

print(lines,"\n")
print("\n")

# Expected output:
# saved
# 3
# ['Hello Thonny\n', 'Second line\n', 'Third line\n']

