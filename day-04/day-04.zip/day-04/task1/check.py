#with closes the file for you  , even if an error happenes
with open("notes.txt","w") as f:
    first = f.readlines().strip()
print(first)