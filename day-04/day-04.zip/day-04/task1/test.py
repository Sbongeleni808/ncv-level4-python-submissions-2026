#NCV Level 4 | Day 4 Files Strings Batch | example: b_check
# Type it in Thonny, run it, then change one thing.
def check_line(text):
    parts = text.split(",")
    if len(parts) != 3:
        return "expected 3 fields"
    if not (parts[0].isdigit() and len(parts[0]) == 7):
        return "bad student number"
    if parts[1].strip() == "":
        return "missing name"
    for piece in parts[2].split(";"):
        if not piece.isdigit():
            return "mark is not a number"
        if int(piece) > 100:
            return "mark above 100"
    return ""


print(check_line("2024001,Thandi,' '65;72"))
print(check_line("2024001, Thandi"))
print(check_line("123,Thandi,65"))
print(check_line("2024001,Thandi,65"))
print(check_line("2024001,Thandi,65;;70"))