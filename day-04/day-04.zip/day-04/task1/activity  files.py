with open("names.txt","w") as f:

    f.write("sipho\n")
    f.write("mlungisi\n")
    f.write("ndaba\n")
    f.write("langa\n")
    f.write("zethu\n")
with open("names.txt") as f:
    print(f.read().strip().upper()) 
    
try :
    with open("names.txt","a") as f:
        f.write("thabo-appended\n")
except FlenotFoundError:
    print("file not found . check name and folder")
    
try :
    with open("nothing.txt") as f:
        print(f.read())
1except FleNotFoundError:
    print("file not found . check name and folder")
    


    

    