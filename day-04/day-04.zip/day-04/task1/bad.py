# NCV Level 4 | Day 4 Files Strings Batch | example: f_lines_bad
# Type it in Thonny, run it, then change one thing.
with open("notes.txt") as f:
    for line in f:
        print(line)

# Expected output:
# saved
# Hello Thonny
# 
# Second line

