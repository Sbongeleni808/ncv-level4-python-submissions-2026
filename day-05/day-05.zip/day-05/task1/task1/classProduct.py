class Product:
    VAT_RATE=0.15
    
    def __init__(self, code, name, price):
        self.code=code
        self.name=name
        self.price=price
        
        
        if price<0:
            raise ValuesError("price can not be negative")
        
        self.price=price
        
    def __str__(self):
        return f"{self.code}-{self.name}:R{self.price:.2f}"
    
    def calc_vat(self):
        return self.price*self.VAT_RATE
    
    def price_including_vat(self):
        return self.price+self.calc_vat()
    
    def apply_discount(self, percentage):
        discount=self.price*percentage / 100
        return self.price-discount
    
    def display_barcode(self):
        return self.code
    
def main():
    product1=Product("P001","keayboard",450.00)
    product2=Product("P002","mouse",250.00)
    
    print(product1)
    print(product2)
    
    print("VAT:",product1.calc_vat())
    print("price including vat:",product1.price_including_vat())
    print("price after 10% discount:",product1.apply_discount(10))
    print("-----------------------------------------")
    print("product code is :",product1.display_barcode())
    print("product code is :",product2.display_barcode())
main()

