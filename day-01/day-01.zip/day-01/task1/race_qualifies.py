athlete=[]
time=[]
text=input("Enter athlete name or x to finalise")
text2=input("Enter atheletes time in minutes or x to finalise")
text3=input("Enter atheletes time in minutes or x to finalise")
while text !="x" :
    if text.isalnum() and text2.isdigit :
        athlete.append(text)
        time.append(int(text2))
    else :
        print("invalid input ignored")
    
    if len(athlete)==0 and time==0:
        print("no athelete")
    
    else:
       text=input("Enter athlete name or x to finalise")
       text2=input("Enter atheletes time in seconds or x to finalise")
       total=0
    
    
    
    
    for m in time:
        total =total+m
        
average = total/len(time)

print ("avarege :", average)

highest=time[0]
lowest=time[0]
for m in time :
    if m>highest:
      highest= m
      if m <lowest:
       lowest=m
       
       
       
print("the winner  is : ", lowest)
print("highest is :", highest)

