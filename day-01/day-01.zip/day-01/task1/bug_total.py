
marks=[65,72 , 48 , 90 , 55]

total=0

for m in marks:
    total =total+m
    
    
avarage =total/len(marks) 

print(avarage)
print(total )