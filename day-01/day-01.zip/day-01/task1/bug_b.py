i=5
total =i +10
print(i)

prnt(total)