marks=[]
text=input("Enter a mark (0-100) or x to finalise")
while text !="x" :
    if text.isdigit() and int(text)<=100 :
        marks.append(int(text))
    else :
        print("invalid mark ignored")
    text = input("Enter a mark (0-100) or x to finalise")
    
if len(marks)==0:
    print("no marks")
    
else:
    total=0
    for m in marks:
        total =total+m
        
average = total/len(marks)

print ("avarege :", average)

highest=marks[0]
lowest=marks[0]
for m in marks :
    if m>highest:
      highest= m
      if m <lowest:
       lowest=m
       
       
       
print("lowest is : ", lowest)
print("highest is :", highest)

bands=