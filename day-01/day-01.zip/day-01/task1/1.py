def show_menu():
    print()
    print("1. Add a mark")
    print("2. Show statistics")
    print("3. Search for a mark")
    print("4. Exit")
 
def add_mark(marks):
    print("(add: not built yet)")
 
def show_stats(marks):
    print("(stats: not built yet)")
 
def search_mark(marks):
    print("(search: not built yet)")
 
def main():
    marks = []
    choice = ""
    while choice != "4":
        show_menu()
        choice = input("Choice: ")
        if choice == "1":
            add_mark(marks)
        elif choice == "2":
            show_stats(marks)
        elif choice == "3":
            search_mark(marks)
        elif choice == "4":
            print("Goodbye.")
        else:
            print("Invalid choice. Enter 1, 2, 3 or 4.")
 
main()
