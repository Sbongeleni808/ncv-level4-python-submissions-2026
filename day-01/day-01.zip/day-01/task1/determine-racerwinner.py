def get_racers():
    racers = {}
    count = int(input("How many racers? "))
    for i in range(count):
        name = input(f"Name of racer {i + 1}: ")
        minutes = float(input(f"Minutes taken by {name}: "))
        racers[name] = minutes
    return racers


def find_winners(racers):
    fastest = min(racers.values())
    return [name for name, mins in racers.items() if mins == fastest], fastest


racers = get_racers()
winners, best_time = find_winners(racers)

if len(winners) == 1:
    print(f"\nThe winner is {winners[0]} with {best_time} minutes!")
else:
    print(f"\nIt's a tie between {', '.join(winners)} with {best_time} minutes!")