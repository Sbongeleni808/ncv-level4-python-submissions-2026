
#Your program must contain the following functions:
def amount_due(facility_code, hours):
#Receive the facility code and number of hours as parameters. Determine the hourly rate, calculate the amount due before VAT, and return it.
    match facility_code:
           case "squa" :
               amount_due=13*hours
           case "swim":
                amount_due=12*hours
           case "gym":
               amount_due=11*hours
           case "wei":
               amount_due=8*hours
    return amount_due
    
def final_amount_due(amount):
#Receive the amount before VAT as a parameter. Add 14% VAT, as specified for this exercise, and return the final amount payable.
    famount=amount+0.14*amount
    return famount

def display(name, amount):
#Receive the customer’s name and final amount payable as parameters. Display the name and amount, showing the amount with the prefix R and two decimal places. This function does not need to return a value.
    print(f"{name} your amount due is R{amount}")

def process_payment():
     code=[ "squa" ,"swim" ,"gym" ,"wei"]
     name=input("please enter your name   ")
    
     print("please enter facility code  ")
     fcode=input()
     while fcode not in code :
       print("please enter facility code , wrong code was entered ")
       fcode=input()
    # validate input
     
     hours=input("please enter time in hours   ")
     amount=amount_due(fcode,float(hours))
     famount=final_amount_due(amount)
     display(name,famount)
    

process_payment()

    
