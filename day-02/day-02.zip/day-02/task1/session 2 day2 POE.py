import random
WishyWashy hires out carpet-cleaning machines. The company needs a Python program to process customer data, simulate machine usage times, and summarise daily payments.
Write a program using functions, random numbers, if statements, loops and lists. Do not use global variables.
Use the following charges:
Machine type	Initial cost	Additional cost per hour
A	R50.00	R30.00
B	R62.50	R36.25
C	R74.87	R40.50
Your program must contain the following functions:
def generate_minutes()
#Generate and return a random integer between 30 and 180, inclusive, representing the number of minutes a customer uses a machine. Use the random module.
    minutes=[]
    for i in range(count):
        minutes.append(random.minute(30,180))
    return minutes

def calc_amount(machine_type, minutes):
#Receive the machine type and minutes used as parameters. Convert the minutes to hours and calculate the amount before VAT:
#Amount before VAT = Initial cost + (Hourly rate × Hours used)
#Return the calculated amount. Charge fractional hours proportionally.
    hour = minutes/60
    
    case "a" or "A" :
        amount =50+30*hour
    
    case "b"  or "B" :
        amount = 62.50+36.25*hour
    
    case "c" or "C" :
        amount = 74.87+40.50*hour
        
return amount

def  calc_total_amount(amount):
#Receive the amount before VAT as a parameter. Calculate VAT using 14% for this exercise, then calculate the total payable.
#Return both the VAT amount and the total payable.
    
    vat=amount*0.14
    total_payable=amount+vat
return vat ,total_payable



def  display_summary(payments)
#Receive a list containing each customer’s total payable, including VAT, as a parameter.
   payments=[]
   number_customers = len(payments)
   


Use the list to calculate and display:
•	The number of customers processed.
•	The combined amount payable by all customers.
•	The average payment per customer.
•	The highest payment.
•	The lowest payment.
5. process_payments()
Prompt the user to enter the number of customers to process. Create an empty list called payments.
Use a loop to perform the following steps for each customer:
•	Prompt for the customer’s name and machine type.
•	Call generate_minutes() to obtain the simulated usage time.
•	Call calc_amount() to calculate the amount before VAT.
•	Call calc_total_amount() to obtain the VAT and total payable.
•	Append the total payable to the payments list.
•	Display an invoice showing the customer’s name, machine type, generated minutes, amount before VAT, VAT amount and total payable.
After processing all customers, pass the payments list to display_summary() to display the daily summary.
Display all monetary amounts with the prefix R and two decimal places.
You may assume that the user enters a positive integer for the number of customers and a valid machine type.
Call process_payments() to start the program.

